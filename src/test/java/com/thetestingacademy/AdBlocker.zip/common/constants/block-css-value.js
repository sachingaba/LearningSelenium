"use strict";

const BLOCK_CSS_VALUE = '{display:none !important; visibility:hidden !important; opacity:0 !important;' + 'position:absolute !important; width:0px !important; height:0px !important;}';