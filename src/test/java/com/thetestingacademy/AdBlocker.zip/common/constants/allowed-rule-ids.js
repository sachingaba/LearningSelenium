"use strict";

const ALLOWED_RULES_IDS = {
  general: 1,
  cookieBanner: 2
};