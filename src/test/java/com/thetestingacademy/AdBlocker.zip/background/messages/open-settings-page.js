"use strict";

const actionInCaseOpenSettingsPage = async () => {
  await openTabWithUrl('/index.html#/settings/blockingSettings');
};