"use strict";

unblockContentScrollingScript('[data-nosnippet="data-nosnippet"]');
unblockContentScrollingScript('.fc-ab-root');