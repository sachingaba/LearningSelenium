"use strict";

unblockContentScrollingScript('[style*="sporcle.com/images"]');