"use strict";

unblockContentScrollingScript('body>div:not(.module-slot):not(#onetrust-consent-sdk):not([id*="tbl-aug"])');