"use strict";

unblockContentScrolling('.fc-ab-root');