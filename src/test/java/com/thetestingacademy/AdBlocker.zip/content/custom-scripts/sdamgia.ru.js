"use strict";

modifySetTimeout('{return f(!1)}', '20000', '0.001');