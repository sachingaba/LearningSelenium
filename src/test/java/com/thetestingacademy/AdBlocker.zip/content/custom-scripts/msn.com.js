"use strict";

hideElemsInShadowDom('unified-mobile-feed', ['[card-type=nativead]'], [], false);
hideElemsInShadowDom('csm-card[card-type=infopane]', [], ['img[id*=nativead]'], true);