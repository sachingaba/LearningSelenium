"use strict";

unblockContentScrollingScript('.fc-ab-root');