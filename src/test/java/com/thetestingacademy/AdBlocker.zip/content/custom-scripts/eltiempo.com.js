"use strict";

unblockContentScrollingScript('.tp-modal');