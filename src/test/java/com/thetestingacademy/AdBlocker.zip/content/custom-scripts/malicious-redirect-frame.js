"use strict";

stopMaliciousRedirect(['head ~ div', 'head ~ iframe']);