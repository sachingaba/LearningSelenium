"use strict";

pruneJson('data.xdt_injected_story_units.ad_media_items');